package ru.sample.duckapp.domain

data class Duck(
    val url: String,
    val message: String,
)