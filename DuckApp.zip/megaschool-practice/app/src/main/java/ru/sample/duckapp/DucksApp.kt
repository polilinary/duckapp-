package ru.sample.duckapp

import android.app.Application

class DucksApp : Application()